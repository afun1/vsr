// background.js (empty for now, logic in popup.js)
